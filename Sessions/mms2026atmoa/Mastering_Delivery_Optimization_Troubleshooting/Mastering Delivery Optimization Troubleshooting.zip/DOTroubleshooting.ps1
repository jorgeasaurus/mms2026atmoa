# Choose the correct package!!

Write-host "Will not P2P!!"
winget search "powerbi desktop"
Write-host ""
Write-Host "Will P2P"
winget search "power bi desktop"    # Will P2P


# Approved Callers
$Geo = Invoke-RestMethod "https://geo.prod.do.dsp.mp.microsoft.com/geo"
$KeyValue = Invoke-RestMethod $geo.KeyValue_EndpointFullUri
$KeyValue.Client_RegisteredCallersFilterList -split ","

# Default logfile location
get-childitem -path "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs" 

# Built in Cmdlets
Get-Command -Module DeliveryOptimization

# Get potential peers from currently cached content
Get-DeliveryOptimizationStatus -PeerInfo

# Get status of Delivery Optimization
Get-DeliveryOptimizationStatus |Select-Object -First 1

Get-DeliveryOptimizationStatus | select-object -Property FileId,Status,DownloadMode,PredefinedCallerApplication
# Performance Counters
Get-DeliveryOptimizationPerfSnap

# Official DO Troubleshooting Script
# https://aka.ms/do-fix

.\DeliveryOptimizationTroubleshooter.ps1

# 2Pint DO Troubleshooting Script

.\Invoke-2PDOTroubleshoot.ps1


# Raw Logs
(Get-DeliveryOptimizationLog).count

Write-host "Number of DO logs with peers:"
(Get-DeliveryOptimizationLog -Path .\code\DO_Logs_Peers\*).count
Write-host "Number of DO logs without peers:"
(Get-DeliveryOptimizationLog -Path .\code\DO_Logs_NoPeers\*).count

Get-DeliveryOptimizationLog -Path .\code\DO_Logs_Peers\* | Out-GridView

# CTelemetryLogger::TraceDownloadCompletedImpl For peers
Get-DeliveryOptimizationLog -Path .\code\DO_Logs_Peers\* | `
Where-object {$_.Function -eq "CTelemetryLogger::TraceDownloadCompletedImpl"} | Out-GridView

# CTelemetryLogger::TraceDownloadCompletedImpl
Get-DeliveryOptimizationLog -Path .\code\DO_Logs_NoPeers\* | `
Where-object {$_.Function -eq "CTelemetryLogger::TraceDownloadCompletedImpl"} | Out-GridView



# CAnnounceSequencer::_OnComplete
Get-DeliveryOptimizationLog -Path .\code\DO_Logs_NoPeers\* | `
Where-object {$_.Function -eq "CAnnounceSequencer::_OnComplete"} | Out-GridView

<#
    Example "cdnIp": "[151.101.22.172]:80;X-CCC:US;X-CID:3;"
    Here are the X-CID values:
    X-CID < 100 is CDN
    X-CID = 100 is MCC on a Distribution Point
    X-CID = 10000 is MCC standalone
    Anything > 10000 you should consider as "internet" MCC. 

    Example log entry:
    Function = CTelemetryLogger::TraceDownloadCompletedImpl

    caller: WU Client Download, cdnIp = [151.101.22.172]:80;X-CCC:US;X-CID:3;, 
        cacheHost = Services:77.111.102.201, 
        bytes: [File: 890599876, CDN: 0, DOINC: 0, rledbat: 0, LAN: 887095296, LinkLocal: 0, 
        Group: 0, inet: 0, lcache: 619708416, req: 886876405, total: 1:890599876;], 
        peers: 3 (local 0), conns: [CDN: 2, DOINC: 2, LAN: 2, LinkLocal: 0, Group: 0, inet: 0], 
        downBps: 4882088, upBps: 10767, downUsageBps: 0, upUsageBps: 0, timeMs: 66399, 
        sessionTimeMs: 67801, groupId = +1Qvt4FTHJImEh1m4YTe1rDEvm7XXII2wzHXc7HDJRxk=, 
        background? 0, uploadRestr: 0, downloadMode: 2, downloadModeSrc: 7, downloadModeReason: 0, isVpn: 0, 
        encrypted? 0, expire at: 2026-05-23T12:34:29.4967928Z, 
        isThrottled = 0	
    	

#>

# 2Pint DO Log analysis script

2

.\Invoke-2PDOLogAnalyzer.ps1 -LogPath .\code\DO_Logs_Peers

